//
//  LegendOfTheFiveRingsCore.h
//  LegendOfTheFiveRingsCore
//
//  Created by Tharak on 30/11/20.
//

#import <Foundation/Foundation.h>

//! Project version number for LegendOfTheFiveRingsCore.
FOUNDATION_EXPORT double LegendOfTheFiveRingsCoreVersionNumber;

//! Project version string for LegendOfTheFiveRingsCore.
FOUNDATION_EXPORT const unsigned char LegendOfTheFiveRingsCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LegendOfTheFiveRingsCore/PublicHeader.h>


